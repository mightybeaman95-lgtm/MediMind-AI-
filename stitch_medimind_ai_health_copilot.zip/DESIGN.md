---
name: Clinical Cybernetic
colors:
  surface: '#0c1321'
  surface-dim: '#0c1321'
  surface-bright: '#323949'
  surface-container-lowest: '#070e1c'
  surface-container-low: '#151b2a'
  surface-container: '#19202e'
  surface-container-high: '#232a39'
  surface-container-highest: '#2e3544'
  on-surface: '#dce2f6'
  on-surface-variant: '#bacac5'
  inverse-surface: '#dce2f6'
  inverse-on-surface: '#2a3040'
  outline: '#859490'
  outline-variant: '#3c4a46'
  surface-tint: '#3cddc7'
  primary: '#57f1db'
  on-primary: '#003731'
  primary-container: '#2dd4bf'
  on-primary-container: '#00574d'
  inverse-primary: '#006b5f'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#5df3b6'
  on-tertiary: '#003825'
  tertiary-container: '#39d69c'
  on-tertiary-container: '#00583c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#62fae3'
  primary-fixed-dim: '#3cddc7'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005047'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#0c1321'
  on-background: '#dce2f6'
  surface-variant: '#2e3544'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.02em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-precision, clinical-grade digital environment engineered for autonomous health intelligence and diagnostic reasoning. The interface evokes unyielding clinical authority, diagnostic vigilance, and calm reassurance under high-stakes conditions. It rejects the sterile, bureaucratic beige of traditional electronic health records (EHRs) as well as the playful, gamified aesthetics of consumer fitness trackers.

The aesthetic fuses **Modern Technical Minimalism** with **Subtle Glassmorphism**:
- Deep, nocturnal oceanic substrates minimize optical fatigue during sustained analysis.
- Luminescent biometric accents (clinical teal and diagnostic cyan) establish precise focal anchors.
- Monospaced data readouts anchor physiological parameters in algorithmic exactitude.
- Translucent panels with crystalline micro-borders establish hierarchy without visual bulk.

## Colors

The palette operates strictly within a calibrated dark-mode system engineered for high contrast, strict WCAG AAA accessibility on body copy, and instant diagnostic triage.

### Surface Architecture
- **Base Canvas (`#0B1220`):** Ultra-deep navy void providing total background absorption.
- **Surface Elevation 1 (`#111C2E`):** Navigational rails, panels, and structural section backdrops.
- **Surface Elevation 2 (`#162236`):** Primary card, modal, and analytical module background.
- **Surface Elevation 3 (`#1E2E48`):** Hover states, nested metric cards, and elevated controls.

### Brand & Interactive Accents
- **Primary Teal (`#2DD4BF`):** Primary actions, active navigation anchors, positive biomarker highlights, and AI conversational prompts.
- **Secondary Cyan (`#38BDF8`):** Telemetry charts, predictive indicators, active selection rings, and secondary interactive targets.
- **Tertiary Emerald (`#34D399`):** Normal clinical ranges, verified vitals, successful diagnoses, and physiological stability flags.

### Diagnostic & Status Accents
- **Amber Warning (`#FBBF24`):** Borderline lab values, medication alerts, and follow-up flags.
- **Crimson Critical (`#F87171`):** Acute alerts, abnormal biometric spikes, contraindications, and urgent actions.

### Typography & Content Shades
- **Text Primary (`#F8FAFC`):** Pure crystalline slate for primary headings, quantitative values, and patient telemetry.
- **Text Secondary (`#94A3B8`):** Neutral slate for qualitative descriptions, labels, units, and timestamps.
- **Text Muted (`#475569`):** Disabled states, structural outlines, and grid lines.

## Typography

The typographic hierarchy pairs the hyper-functional neo-grotesque `Inter` with the technical monospace engine `JetBrains Mono`.

- **Inter:** Drives all conversational interactions, clinical summaries, structural headers, and narrative diagnostic copy. Tracking is tightened slightly across large headings to maintain structural density.
- **JetBrains Mono:** Reserved exclusively for clinical measurements, lab results (e.g., `128/82 mmHg`, `98.4% SpO2`, `5.7 mmol/L`), diagnostic codes (ICD-10), pill dosages, micro-badges, and timestamp logs. Its fixed glyph metrics prevent layout shifting during dynamic streaming and telemetry re-renders.
- **Caps Styling:** `label-caps` must strictly be set in `text-transform: uppercase` with wide tracking (`0.08em`) to guarantee quick recognition on micro-displays and clinical panels.

## Layout & Spacing

The layout operates on a flexible 12-column grid system bounded by high-density diagnostic spacing rules.

### Responsive Breakpoints
- **Desktop (≥ 1280px):** 12-column layout. Left persistent utility navigation (80px collapsed / 260px expanded), central analytical dashboard / copilot thread (7-8 columns), and contextual biometric inspector panel (4-5 columns). `gutter: 1.5rem`, `margin: 2rem`.
- **Tablet (768px – 1279px):** 8-column layout. Central feed and biometric sidebar stack into accessible dual-column or toggleable views. Navigation collapses to a slim icon rail. `gutter: 1rem`, `margin: 1.5rem`.
- **Mobile (< 768px):** 4-column layout. Fully vertical flow with bottom-anchored persistent Copilot prompt bar and biometric drawers. `gutter-mobile: 1rem`, `margin-mobile: 1rem`.

### Density Model
Spacing is disciplined around an explicit 8pt baseline (`0.5rem` / `space-sm`), with `0.25rem` (`space-xs`) reserved for tight data readouts, micro-indicators, and inline badge padding. Empty space is structural rather than decorative, keeping analytical modules compact and scannable without horizontal scroll bottlenecks.

## Elevation & Depth

Visual hierarchy uses a dark-spectrum translucent layering model that combines **Tonal Surface Tiers**, **Subtle Glassmorphic Micro-Borders**, and **Cyan/Teal Ambient Photonic Glows**.

### Depth Tiers
- **Tier 0 (Base Bed):** Flat `#0B1220`. Houses canvas-level grid patterns and structural dividers.
- **Tier 1 (Panels & Sidebar):** `#111C2E` with 0.85 opacity and `backdrop-filter: blur(12px)`. Outlined with a top-lit micro-border: `1px solid rgba(255, 255, 255, 0.05)`.
- **Tier 2 (Cards & Modules):** `#162236` at 0.70 opacity with `backdrop-filter: blur(16px)`. Border: `1px solid rgba(56, 189, 248, 0.12)`. Subtle directional drop shadow: `0 8px 32px -4px rgba(3, 7, 18, 0.6)`.
- **Tier 3 (Floating Modals & Diagnostic Drawers):** `#1E2E48` at 0.95 opacity with `backdrop-filter: blur(24px)`. Border: `1px solid rgba(45, 212, 191, 0.25)`. Elevation shadow: `0 20px 48px -8px rgba(0, 0, 0, 0.8)`.

### Chromatic Glow Tokens
- **Telemetry Glow (Normal):** `box-shadow: 0 0 16px -2px rgba(45, 212, 191, 0.2)`
- **Telemetry Glow (Alert):** `box-shadow: 0 0 20px 0px rgba(248, 113, 113, 0.3)`
- **Copilot Active Processing:** Pulsing aura on conversational cards using `0 0 24px rgba(56, 189, 248, 0.15)`.

## Shapes

The design system employs a **Rounded (Level 2)** shape language, balancing software warmth with geometric precision.

- **Micro Shapes (`rounded-sm` / 4px):** Checkboxes, biometric sparkline markers, tooltips, inline data pills.
- **Standard Control Shapes (`rounded` / 8px):** Buttons, input fields, dropdown trigger buttons, tab items, chip controls.
- **Structural Cards (`rounded-lg` / 16px):** Telemetry cards, chat dialogue bubbles, lab panels, modal overlays.
- **Hero Containers (`rounded-xl` / 24px):** Diagnostic summary hubs, floating command sheets.
- **Full Pill (`rounded-full`):** Status indicator dots, biometric status chips, avatar containers, urgent floating action buttons (FABs).

## Components

### Buttons
- **Primary:** Solid `#2DD4BF` background, `#0B1220` typography (`font-weight: 600`), 8px border radius. Hover: `#14B8A6` with `0 0 16px rgba(45, 212, 191, 0.4)`. Focus: Ring of 2px `#38BDF8` with 2px offset in `#0B1220`.
- **Secondary / Ghost:** Transparent background, `#162236` resting fill, 1px border `rgba(56, 189, 248, 0.2)`. Text: `#F8FAFC`. Hover: `rgba(56, 189, 248, 0.08)` fill with border `rgba(56, 189, 248, 0.4)`.
- **Destructive / Emergency:** `#F87171` fill with `#0B1220` text for immediate actions, or transparent with `1px solid #F87171` and crimson glow for safety confirmations.

### Chips & Glowing Status Badges
- **Structure:** Pill-shaped (`rounded-full`), padding `2px 10px`, typography `label-caps`.
- **Normal / Nominal:** Background `rgba(52, 211, 153, 0.1)`, text `#34D399`, border `1px solid rgba(52, 211, 153, 0.2)`. Preceded by a 6px circular dot with `box-shadow: 0 0 8px #34D399`.
- **Monitoring / Processing:** Background `rgba(56, 189, 248, 0.1)`, text `#38BDF8`, border `1px solid rgba(56, 189, 248, 0.2)`.
- **Elevated / Warning:** Background `rgba(251, 191, 36, 0.1)`, text `#FBBF24`, border `1px solid rgba(251, 191, 36, 0.2)`.
- **Critical:** Background `rgba(248, 113, 113, 0.15)`, text `#F87171`, border `1px solid rgba(248, 113, 113, 0.4)`. Dot contains an animated ping ring.

### Telemetry & Analytical Cards
- Standard surface `#162236` at 70% opacity, 16px corner radius, padding `space-lg`.
- Top-lit accent gradient border via subtle CSS mask or border rule (`rgba(56, 189, 248, 0.12)`).
- Card headers strictly display the title in `Inter 14px SemiBold` (`#94A3B8`) paired with an aligned `JetBrains Mono` status badge.
- Telemetry readouts display numerical outputs using `telemetry-lg` (`#F8FAFC`) with inline subscript unit descriptions (`#94A3B8`).

### Input Fields & Search Bars
- Resting background `#111C2E`, border `1px solid rgba(148, 163, 184, 0.15)`, text `#F8FAFC`.
- Focus state: Border transitions to `#2DD4BF`, background shifts to `#162236`, illuminated by `0 0 12px rgba(45, 212, 191, 0.15)`. Placeholder text in `#475569`.
- AI Prompts / Copilot Inputs: Include an integrated trailing accessory row with active microphone audio wave toggles and mono model identifier chips.

### Checkboxes & Radio Buttons
- 18px box/circle, background `#111C2E`, border `1.5px solid rgba(148, 163, 184, 0.3)`.
- Checked: Fill `#2DD4BF`, border `#2DD4BF`, displaying a deep navy `#0B1220` check or inner circle. Subtle teal illumination on selection.

### Lists & Lab Value Tables
- Hoverable row states transitioning to `rgba(56, 189, 248, 0.04)`.
- Alternating rows avoid striped fills; separation is maintained strictly with hairline borders `1px solid rgba(255, 255, 255, 0.04)`.
- Lab columns organize value, reference interval, and delta variance in fixed-width `JetBrains Mono` layouts for vertical column alignment.

### Specialized Component: AI Diagnostic Thought Stream
- Conversational Copilot bubble with a subtle left accent spine (`2px solid #2DD4BF`).
- Nested collapsible "Clinical Rationale" sub-panel in `#0B1220` with monospaced citations and confidence score percentages.